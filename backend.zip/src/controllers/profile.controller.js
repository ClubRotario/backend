const { request, response } = require('express');

const getProfile = async(req = request, res = response) => {
    try{
        const { user_id } = req;
    }catch(error){

    }
};

module.exports = { getProfile }