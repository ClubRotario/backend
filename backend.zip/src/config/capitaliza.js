const capitalizeString = (string) => {

};

module.exports = { capitalizeString };