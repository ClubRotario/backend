## Descripción
Backend para el proyecto del Club Rotario de la ciudad de La Paz
Proyecto para la clase de ingeniería en software 2 – primer periodo del 2021 UJCV.

prueba de repo

## Script
`npm run dev` Para poner el servidor en marcha.
